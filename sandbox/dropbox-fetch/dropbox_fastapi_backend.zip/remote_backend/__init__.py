"""Remote file backend service (FastAPI).

Provider-first design: add providers under `remote_backend.providers`.
"""
__all__ = []
