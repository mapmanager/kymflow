# NEW_PROJECT_SETUP_GUIDE.md

A practical recipe for a human to set up this system in a new project.

## 1) Create folders
- Create `tickets/`
- Optionally create `docs/` and `tests/` if not present

## 2) Copy templates
Copy these into your project (customize names as needed):
- `tickets/CODEX_RULES.md` (start from CODEX_RULES_TEMPLATE.md)
- `tickets/TICKET_TEMPLATE.md`
- `ARCHITECTURE_SNAPSHOT_v1.md` (start from ARCHITECTURE_SNAPSHOT_TEMPLATE.md)
- `ESCALATION_PROTOCOL.md`
- `ROLLBACK_STRATEGY.md`
- `MULTI_ARCHITECT_PROTOCOL.md`
- `GOVERNANCE_MODES.md`

## 3) Decide scope defaults
Pick your “Scoped Repository Mode” boundary:
- Folder: recommended
- Module: OK
- Full repo: only if needed

Write the default scope into ARCHITECTURE_SNAPSHOT_v1.md.

## 4) Initialize Architect LLM chat
Open a new chat and upload:
- ARCHITECTURE_SNAPSHOT_v1.md
- tickets/CODEX_RULES.md
- tickets/TICKET_TEMPLATE.md
- ESCALATION_PROTOCOL.md
- ROLLBACK_STRATEGY.md
- MULTI_ARCHITECT_PROTOCOL.md
- GOVERNANCE_MODES.md

Paste:
> You are the Architect LLM. Read the governance docs.  
> Explain the workflow back to me, then ask clarifying questions before drafting any tickets.  
> Draft tickets only using TICKET_TEMPLATE.md and enforce scope strictly.

## 5) Initialize Codex session
Paste into Codex once:
> Read tickets/CODEX_RULES.md and acknowledge the rules.  
> For each ticket, only edit allowed files and write tickets/<ticket>_codex_report.md with diff + commands run + self-critique.

## 6) Run a “smoke ticket”
Pick an extremely small change:
- docstring update
- add a unit test
- rename a variable in one file
Prove the loop works.

## 7) Iterate
- Keep tickets small.
- When architecture changes, version-bump ARCHITECTURE_SNAPSHOT_vX.
- Use ESCALATION_PROTOCOL when blocked.
