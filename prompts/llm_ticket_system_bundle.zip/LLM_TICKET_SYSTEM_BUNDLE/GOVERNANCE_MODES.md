# Governance Modes

This file defines optional “modes” for tickets. A ticket should declare which mode it is using.

## 1) Strict Mode
Use when stability matters.
- No refactors (unless explicitly needed to fix the bug)
- No API signature changes
- Minimal diffs
- Public behavior should remain stable
- Strong preference for adding/adjusting tests

## 2) Refactor Mode
Use when you want controlled restructuring.
- Structural cleanup allowed
- API changes allowed if ticket explicitly permits
- Must update ARCHITECTURE_SNAPSHOT_vX if architecture materially changes
- Add tests or keep existing tests passing

## 3) Exploration Mode
Use for prototypes and algorithm spikes.
- Rapid iteration allowed
- Must isolate experimental code paths (e.g., `sandbox/`, `experimental/`)
- Must not destabilize production modules
- May be merged later after hardening + tests

## Guidance
- Default to Strict Mode.
- Use Refactor Mode sparingly, and keep ticket scopes narrow.
- Use Exploration Mode only with explicit opt-in and clear boundaries.
