# ESCALATION_PROTOCOL.md

Use this when the executor cannot proceed without violating ticket constraints.

## When to escalate
- Required change is outside allowed scope
- Ticket is ambiguous / missing necessary info
- Conflicting requirements
- Validation fails for reasons not caused by scoped changes
- Tooling/platform mismatch (e.g., missing dependency)

## How to escalate (Executor)
1) Stop making changes.
2) Write a report section titled **ESCALATION** that includes:
   - What is blocked
   - Why it cannot be solved within scope
   - Options:
     A) Minimal scope expansion (name exact file)
     B) Alternative approach inside scope (if possible)
     C) Defer to a later ticket
3) Wait for human/architect decision.

## How to resolve (Human + Architect)
- Choose one option and write a new ticket or amend the current ticket.
- If expanding scope, make it explicit and minimal.
- If deferring, create a follow-up ticket.

## Principle
Escalation is success: it prevents silent drift.
