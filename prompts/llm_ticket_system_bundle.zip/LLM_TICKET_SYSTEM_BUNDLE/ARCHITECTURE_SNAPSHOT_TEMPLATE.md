# ARCHITECTURE_SNAPSHOT_v1.md (Template)

> Purpose: A concise, authoritative “source of truth” describing the current module architecture.
> Update this when you make material architectural changes.

## Scope
- Repository:
- Scoped folder(s):
- Entry points:
- Public API surface (functions/classes intended for external use):

## Problem Statement
- What problem does this module solve?
- What inputs does it consume?
- What outputs does it produce?

## Key invariants (DO NOT BREAK)
List domain rules that must remain true.
Examples:
- Identity keys for merges: (rel_path, roi_id)
- One estimate per (file, roi_id) for global analysis
- Stable summary schema keys

## Modules / files
Describe each module and its role.
- file_a.py: ...
- file_b.py: ...
- tests/: ...
- docs/: ...

## Data model
- Dataclasses / enums used across modules
- Key fields and semantics

## Pipelines / flows
Describe typical usage flows.
- Load → analyze → summarize → plot
- Batch flow

## Validation / testing
- How to run tests
- How to run example scripts
- Known constraints / platform notes (macOS multiprocessing, etc.)

## Open design questions
- Things intentionally deferred
- Known limitations

## Versioning
- Increment snapshot version when structure changes materially:
  - v1 → v2 when modules split/merged, APIs change, pipeline semantics change, etc.
