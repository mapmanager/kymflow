# ROLLBACK_STRATEGY.md

This system assumes git is available as the primary rollback mechanism.
The goal is safety without making tickets cumbersome.

## Recommended workflow
- Create a branch per ticket or per small batch of tickets.
- Commit before and after a ticket implementation.
- If changes go wrong, revert/checkout.

## Ticket-level rollback guidance
Tickets should be:
- small
- atomic
- scope-bounded

Executor reports should include:
- what changed
- how to validate
- risks/tradeoffs

## If a ticket fails
- Revert the branch or reset to last known good commit.
- Capture the failure mode in a follow-up ticket.
- Avoid “fix-forward” chains without tests.

## Optional hardening (advanced)
- Require a pre-ticket checkpoint commit.
- Require `git diff` in the report.
- Require “expected output markers” for example scripts.
