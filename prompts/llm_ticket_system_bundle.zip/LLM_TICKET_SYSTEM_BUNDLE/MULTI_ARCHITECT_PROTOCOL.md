# MULTI_ARCHITECT_PROTOCOL.md

This protocol supports multiple Architect LLMs drafting tickets (ChatGPT, Claude, etc.)
while keeping execution safe and consistent.

## Roles
- Architect LLM A: proposes design/ticket
- Architect LLM B: reviews or proposes alternative
- Human: final arbiter

## Rules
1) Only one ticket is “active” at a time.
2) If multiple architects propose tickets:
   - Compare tickets side-by-side
   - Human selects one or merges constraints explicitly
3) Tickets must not contradict ARCHITECTURE_SNAPSHOT_vX invariants.
4) If architects disagree on design:
   - Create a short Design Decision Record (DDR) in docs/:
     `docs/ddr_<topic>_v1.md`
   - Human chooses and records decision.

## Best practice: two-pass drafting
- Pass 1: Architect A drafts ticket
- Pass 2: Architect B critiques ticket for ambiguity, drift, testing gaps
- Human approves final ticket

## Don’t do
- Don’t run multiple executor sessions on overlapping scopes concurrently.
- Don’t allow “silent compromise” where an architect changes requirements mid-ticket.
