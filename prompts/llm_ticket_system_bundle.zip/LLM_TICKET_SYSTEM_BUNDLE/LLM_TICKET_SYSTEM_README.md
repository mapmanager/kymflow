# LLM Ticket System Bundle (ChatGPT ↔ Codex ↔ Human) — README

This bundle defines a lightweight governance workflow for iterative algorithm/software development using:
- **Architect LLM(s)** (e.g., ChatGPT, Claude): design + ticket authoring
- **Executor LLM** (e.g., Codex): scoped code edits + verification
- **Human**: approvals, arbitration, and repository control (git)

The goal is **high leverage with low drift**:
- small, bounded edits
- deterministic validation
- human in the loop
- reproducible reporting
- clean escalation when constraints block progress

---

## Core concepts

### Roles
- **Architect LLM**: interprets goals, proposes architecture, writes tickets.
- **Executor LLM (Codex)**: implements tickets **within strict scope**, runs checks, produces a report.
- **Human**: decides priorities, approves tickets, runs/merges changes, resolves disagreements.

### Artifacts
- `tickets/CODEX_RULES.md`: the executor contract (hard constraints)
- `tickets/TICKET_TEMPLATE.md`: ticket structure
- `ARCHITECTURE_SNAPSHOT_vX.md`: current architecture baseline
- `tickets/ticket_<n>.md`: one ticket (work unit)
- `tickets/ticket_<n>_codex_report.md`: executor’s implementation report

### Scoped Repository Mode
Every ticket declares an allowed edit scope:
- a folder (recommended),
- a module,
- or the full repo.

Anything outside scope must trigger escalation, not silent edits.

---

## Operating loop (bi-directional)

1) **Human + Architect LLM** discuss design and constraints.
2) Architect LLM writes **one ticket** (bounded scope, clear acceptance criteria).
3) Human hands the ticket to **Codex** (Executor LLM).
4) Codex:
   - edits only allowed files
   - runs validation commands
   - produces report with diff + self-critique
5) Human pastes report back to Architect LLM for review.
6) Architect LLM critiques report, suggests adjustments and next ticket.
7) Repeat.

---

## Governance modes

Choose one per ticket (or per phase):
- **Strict Mode**: no refactors, minimal diffs, keep public behavior stable.
- **Refactor Mode**: controlled structural improvements, API changes allowed if ticket says so.
- **Exploration Mode**: prototypes allowed; must be clearly separated from production paths.

See `GOVERNANCE_MODES.md`.

---

## Failure modes to watch

- **Scope drift**: edits outside allowed files/folder.
- **API drift**: signatures changed without explicit ticket permission.
- **Silent behavior change**: same tests pass but semantics changed.
- **Non-repro validation**: executor didn’t run commands or ran wrong ones.
- **Spec ambiguity**: ticket unclear → executor guesses.

Use `ESCALATION_PROTOCOL.md` when blocked.

---

## Minimal startup checklist

1) Create a `tickets/` folder in the project.
2) Copy in:
   - `CODEX_RULES.md` (from template or customized)
   - `TICKET_TEMPLATE.md`
3) Create `ARCHITECTURE_SNAPSHOT_v1.md` from the template.
4) Run one small ticket to prove the loop works.
5) Iterate.

---

## Quick prompts (human recipes)

### Architect LLM initialization
Paste into a new chat and upload these docs:
- `LLM_TICKET_SYSTEM_README.md`
- `ARCHITECTURE_SNAPSHOT_v1.md` (or vX)
- `tickets/CODEX_RULES.md`
- `tickets/TICKET_TEMPLATE.md`
- `ESCALATION_PROTOCOL.md`
- `ROLLBACK_STRATEGY.md`
- `MULTI_ARCHITECT_PROTOCOL.md`

Prompt:
> You are the Architect LLM. Read the attached governance docs.  
> Explain the workflow back to me, then ask clarifying questions before drafting a ticket.  
> When you draft tickets, follow TICKET_TEMPLATE.md and enforce scope strictly.

### Codex initialization
Paste once per Codex session:
> Read `tickets/CODEX_RULES.md` and acknowledge the rules.  
> You may only edit files allowed by the next ticket.  
> For each ticket, write `tickets/<ticket_name>_codex_report.md` with diff + commands run + self-critique.

Then for each ticket:
> Implement the following ticket: `<path/to/ticket_X.md>`

---

## Multi-architect support

If multiple Architect LLMs draft tickets, use:
- `MULTI_ARCHITECT_PROTOCOL.md` to resolve conflicts
- human is final arbiter

---

## What to customize per project
- Key columns / domain invariants in `ARCHITECTURE_SNAPSHOT_vX.md`
- Validation commands in `tickets/CODEX_RULES.md` (e.g., `uv run pytest -q`)
- Scope model (folder/module/repo)
- Output schemas to keep stable

---

## License / usage
This is a process bundle; copy and adapt freely.
